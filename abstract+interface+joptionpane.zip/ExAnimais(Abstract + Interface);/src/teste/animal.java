package teste;

public abstract class animal {
	int pernas;
	boolean bico;
	boolean asas;
	boolean carnivoro;
	String nome;
	
}
