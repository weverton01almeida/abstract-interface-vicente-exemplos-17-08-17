package teste;

public interface Voar {
	public String voar();
}
