package teste;

public class cachorro extends animal implements Comer {
	@Override
	public String comer() {
		// TODO Auto-generated method stub
		return "Comendo carne...";
	}

}
