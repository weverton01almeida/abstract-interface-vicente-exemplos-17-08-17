package teste;

public interface Comer {
	public String comer();
}
