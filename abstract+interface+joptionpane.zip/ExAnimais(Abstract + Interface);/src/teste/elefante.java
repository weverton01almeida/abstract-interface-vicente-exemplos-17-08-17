package teste;

public class elefante extends animal implements Comer {
	@Override
	public String comer() {
		return "Comendo plantas...";
	}
}
